package com.akash.flashlight;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;


public class FlashlightActivity extends AppCompatActivity {
    private static final String TAG = "FlashLightActivity";
    private CameraManager mCameraManager;
    private String mCameraId;
    private ImageButton mTorchOnOffButton;
    private Boolean isTorchOn;
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("FlashLightActivity","onCreate");
        setContentView(R.layout.activity_flashlight);
        mTorchOnOffButton = (ImageButton) findViewById(R.id.button_on_off);
        isTorchOn = false;
        boolean isFlashAvailable = getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        if (!isFlashAvailable){
            AlertDialog alert = new AlertDialog.Builder(FlashlightActivity.this)
                    .create();
            alert.setTitle("Error !!");
            alert.setMessage("Your device doesn't support flash light!");
            alert.setButton(DialogInterface.BUTTON_POSITIVE, "OK", (dialog, which) -> {
                // closing the application
                finish();
                System.exit(0);
            });
            alert.show();
            return;
        }

        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            mCameraId = mCameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        mTorchOnOffButton.setOnClickListener(v -> {
            try {
                if (isTorchOn) {
                    turnOffFlashLight();
                    isTorchOn = false;
                } else {
                    turnOnFlashLight();
                    isTorchOn = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    @SuppressLint("ObsoleteSdkInt")
    public void turnOnFlashLight() {
        Log.d(TAG,"turnOnFlashLight()");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                count++;
                if(count ==2){
                    count =0;

                }
                mCameraManager.setTorchMode(mCameraId, true);
                mTorchOnOffButton.setImageResource(R.drawable.on);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @SuppressLint("ObsoleteSdkInt")
    public void turnOffFlashLight() {
        Log.d(TAG,"turnOffFlashLight()");

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mCameraManager.setTorchMode(mCameraId, false);
                mTorchOnOffButton.setImageResource(R.drawable.off);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(isTorchOn){
            count =0;
            turnOffFlashLight();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if(isTorchOn){
            count =0;
            turnOffFlashLight();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        if(isTorchOn){
            count =0;
            turnOnFlashLight();
        }
    }
}
